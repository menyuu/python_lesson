from lesson_package.tools import utils

def sing():
    return 'ojgo453jggiorsagoiawjo'

def cry():
    return utils.say_twice('gsiroajgoiw4qug09wa')